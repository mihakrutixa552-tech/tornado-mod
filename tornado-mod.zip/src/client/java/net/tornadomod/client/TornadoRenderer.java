package net.tornadomod.client;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.tornadomod.TornadoEntity;

/** The tornado has no model: the funnel is drawn with particles in TornadoEntity#clientEffects. */
public class TornadoRenderer extends EntityRenderer<TornadoEntity, EntityRenderState> {
	public TornadoRenderer(EntityRendererProvider.Context context) {
		super(context);
	}

	@Override
	public EntityRenderState createRenderState() {
		return new EntityRenderState();
	}
}
