package net.tornadomod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class TornadoEntity extends Entity {
	private static final EntityDataAccessor<Integer> DATA_STRENGTH =
			SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Integer> DATA_MAX_LIFE =
			SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.INT);

	/** Direction of travel (radians), server side only. */
	private double heading;

	public TornadoEntity(EntityType<?> type, Level level) {
		super(type, level);
		this.noPhysics = true;
		this.setNoGravity(true);
		this.setInvulnerable(true);
		this.heading = this.random.nextDouble() * Math.PI * 2.0;
		int span = TornadoMod.LIFETIME_MAX_TICKS - TornadoMod.LIFETIME_MIN_TICKS;
		this.entityData.set(DATA_MAX_LIFE, TornadoMod.LIFETIME_MIN_TICKS + this.random.nextInt(span + 1));
	}

	// ------------------------------------------------------------------ data

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		builder.define(DATA_STRENGTH, 3);
		builder.define(DATA_MAX_LIFE, TornadoMod.LIFETIME_MIN_TICKS);
	}

	public int getStrength() {
		return this.entityData.get(DATA_STRENGTH);
	}

	public void setStrength(int strength) {
		this.entityData.set(DATA_STRENGTH, Mth.clamp(strength, 1, 5));
	}

	@Override
	protected void readAdditionalSaveData(ValueInput input) {
		setStrength(input.getIntOr("Strength", 3));
		this.entityData.set(DATA_MAX_LIFE, input.getIntOr("MaxLife", TornadoMod.LIFETIME_MIN_TICKS));
		this.tickCount = input.getIntOr("Age", 0);
	}

	@Override
	protected void addAdditionalSaveData(ValueOutput output) {
		output.putInt("Strength", getStrength());
		output.putInt("MaxLife", this.entityData.get(DATA_MAX_LIFE));
		output.putInt("Age", this.tickCount);
	}

	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		return false; // tornadoes can't be damaged
	}

	// -------------------------------------------------------------- geometry

	private double baseRadius() {
		return 1.5 + 0.4 * getStrength();
	}

	private double topRadius() {
		return 5.0 + 2.0 * getStrength();
	}

	private double height() {
		return 16.0 + 6.0 * getStrength();
	}

	/** 0..1: grows in during the first 3 s, fades out during the last 5 s of life. */
	private double intensity() {
		int maxLife = this.entityData.get(DATA_MAX_LIFE);
		double in = Mth.clamp(this.tickCount / 60.0, 0.0, 1.0);
		double out = Mth.clamp((maxLife - this.tickCount) / 100.0, 0.0, 1.0);
		return Math.max(0.1, Math.min(in, out));
	}

	/** Funnel radius at a height above the base: narrow at the bottom, flaring upwards. */
	private double funnelRadius(double relY, double k) {
		double t = Mth.clamp(relY / (height() * k), 0.0, 1.0);
		t = Math.pow(t, 1.6);
		return (baseRadius() + (topRadius() - baseRadius()) * t) * k;
	}

	private AABB influenceBox(double k) {
		double r = topRadius() * k;
		return new AABB(getX() - r, getY() - 2.0, getZ() - r, getX() + r, getY() + height() * k, getZ() + r);
	}

	// ------------------------------------------------------------------ tick

	@Override
	public void tick() {
		super.tick();

		if (this.level() instanceof ServerLevel server) {
			if (this.tickCount >= this.entityData.get(DATA_MAX_LIFE)) {
				this.discard();
				return;
			}
			moveAlongSurface(server);
			if (this.tickCount % 2 == 0) {
				ripBlocks(server);
			}
			affectEntities(server);
		} else {
			clientEffects();
		}
	}

	// ---------------------------------------------------------------- server

	private void moveAlongSurface(ServerLevel level) {
		double speed = 0.07 + 0.015 * getStrength();
		this.heading += (this.random.nextDouble() - 0.5) * 0.08;

		double nx = getX() + Math.cos(this.heading) * speed;
		double nz = getZ() + Math.sin(this.heading) * speed;
		int bx = Mth.floor(nx);
		int bz = Mth.floor(nz);

		if (!level.hasChunkAt(new BlockPos(bx, 0, bz))) {
			this.heading += Math.PI * 0.5; // don't wander into unloaded chunks
			return;
		}

		// Heightmap includes water surface, ignores leaves -> follows ground and water.
		int surface = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
		double ny = getY() + Mth.clamp((surface - getY()) * 0.25, -0.5, 0.5);
		this.setPos(nx, ny, nz);
	}

	private static boolean isAffected(Entity e) {
		if (e instanceof TornadoEntity || e instanceof HangingEntity) return false;
		if (e.isSpectator() || e.isRemoved() || e.isPassenger()) return false;
		if (e instanceof Player p && p.isCreative()) return false;
		if (e instanceof LivingEntity le && le.getMaxHealth() > 100.0F) return false; // bosses
		return true;
	}

	private void affectEntities(ServerLevel level) {
		int s = getStrength();
		double k = intensity();
		double h = height() * k;

		for (Entity e : level.getEntities(this, influenceBox(k), TornadoEntity::isAffected)) {
			double dx = e.getX() - getX();
			double dz = e.getZ() - getZ();
			double dist = Math.sqrt(dx * dx + dz * dz);
			double relY = e.getY() - getY();
			if (relY < -2.0 || relY > h) continue;

			double radius = funnelRadius(Math.max(relY, 0.0), k);
			if (dist > radius + e.getBbWidth()) continue;

			double nd = Math.max(dist, 0.4);
			double ux = dx / nd, uz = dz / nd; // outward
			double tx = -uz, tz = ux;          // tangent (counter-clockwise)

			e.resetFallDistance();
			Vec3 old = e.getDeltaMovement();
			Vec3 v;

			boolean fling = relY > h * 0.8 || (relY > h * 0.35 && this.random.nextFloat() < 0.012F);
			if (fling) {
				// thrown out of the funnel
				double out = 0.9 + 0.25 * s;
				v = new Vec3(ux * out + tx * 0.4, 0.3, uz * out + tz * 0.4);
				if (e instanceof LivingEntity living && !living.hasEffect(MobEffects.SLOW_FALLING)) {
					living.hurtServer(level, level.damageSources().flyIntoWall(), 1.0F + s);
					// soft landing, otherwise a fall from 30+ blocks is always lethal
					living.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0, false, false));
				}
			} else {
				// spiral: spin around + pull inwards + lift
				double spin = 0.03 + 0.012 * s;
				double pull = (0.045 + 0.010 * s) * (0.4 + dist / Math.max(radius, 0.5));
				double lift = 0.085 + 0.008 * s;
				v = new Vec3(
						old.x * 0.85 + tx * spin - ux * pull,
						old.y * 0.92 + lift,
						old.z * 0.85 + tz * spin - uz * pull);

				double maxH = 0.7 + 0.12 * s;
				double hs = Math.hypot(v.x, v.z);
				if (hs > maxH) {
					v = new Vec3(v.x * maxH / hs, v.y, v.z * maxH / hs);
				}
				v = new Vec3(v.x, Mth.clamp(v.y, -0.6, 0.3 + 0.04 * s), v.z);
			}

			e.setDeltaMovement(v);
			if (e instanceof ServerPlayer) {
				e.hurtMarked = true; // make the server send the new motion to the client
			}
		}
	}

	private void ripBlocks(ServerLevel level) {
		int s = getStrength();
		double k = intensity();

		int cap = 30 + 25 * s; // limit of falling-block entities around the tornado
		if (level.getEntitiesOfClass(FallingBlockEntity.class, influenceBox(k)).size() >= cap) return;

		double reach = (2.5 + 1.5 * s) * k;
		int attempts = 2 + s * 3;

		for (int i = 0; i < attempts; i++) {
			double angle = this.random.nextDouble() * Math.PI * 2.0;
			double r = Math.sqrt(this.random.nextDouble()) * reach;
			int x = Mth.floor(getX() + Math.cos(angle) * r);
			int z = Mth.floor(getZ() + Math.sin(angle) * r);
			if (!level.hasChunkAt(new BlockPos(x, 0, z))) continue;

			// topmost solid-or-fluid block of the column (leaves count), then up to 2 below it
			int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
			BlockPos pos = new BlockPos(x, top - 1 - this.random.nextInt(3), z);
			BlockState state = level.getBlockState(pos);

			if (!canRip(level, pos, state) || !isExposed(level, pos)) continue;

			FallingBlockEntity falling = FallingBlockEntity.fall(level, pos, state);
			falling.setDeltaMovement(0.0, 0.3 + 0.05 * s, 0.0);
		}
	}

	/** Light and medium blocks only. Never block entities (chests...), obsidian, bedrock, ores, stone. */
	private static boolean canRip(ServerLevel level, BlockPos pos, BlockState state) {
		if (state.isAir() || !state.getFluidState().isEmpty()) return false;
		if (state.hasBlockEntity()) return false;
		if (state.is(Blocks.OBSIDIAN) || state.is(Blocks.CRYING_OBSIDIAN) || state.is(Blocks.BEDROCK)) return false;
		float hardness = state.getDestroySpeed(level, pos);
		if (hardness < 0.0F || hardness > 2.0F) return false;
		return !state.requiresCorrectToolForDrops();
	}

	private static boolean isExposed(ServerLevel level, BlockPos pos) {
		for (Direction d : Direction.values()) {
			BlockState n = level.getBlockState(pos.relative(d));
			if (n.isAir() || n.canBeReplaced()) return true;
		}
		return false;
	}

	// ---------------------------------------------------------------- client

	private void clientEffects() {
		int s = getStrength();
		double k = intensity();
		double h = height() * k;

		BlockState ground = this.level().getBlockState(BlockPos.containing(getX(), getY() - 1.0, getZ()));
		if (ground.isAir() || !ground.getFluidState().isEmpty()) {
			ground = Blocks.DIRT.defaultBlockState();
		}
		ParticleOptions debris = new BlockParticleOption(ParticleTypes.BLOCK, ground);

		int count = (int) ((10 + 6 * s) * k * TornadoMod.PARTICLE_DENSITY);
		double spin = 0.25 + 0.05 * s;

		for (int i = 0; i < count; i++) {
			double t = Math.pow(this.random.nextDouble(), 1.4); // more particles near the ground
			double relY = t * h;
			double r = funnelRadius(relY, k) * (0.75 + this.random.nextDouble() * 0.35);
			double angle = this.tickCount * 0.5 + t * 10.0 + this.random.nextDouble() * 0.6;

			double px = getX() + Math.cos(angle) * r;
			double py = getY() + relY;
			double pz = getZ() + Math.sin(angle) * r;
			double vx = -Math.sin(angle) * spin;
			double vz = Math.cos(angle) * spin;
			double vy = 0.05 + this.random.nextDouble() * 0.2;

			double roll = this.random.nextDouble();
			ParticleOptions type = roll < 0.55 ? ParticleTypes.LARGE_SMOKE
					: roll < 0.80 ? ParticleTypes.CLOUD
					: debris;
			this.level().addAlwaysVisibleParticle(type, px, py, pz, vx, vy, vz);
		}

		// Sound: pitch and volume depend on how close the nearest player is
		Player near = this.level().getNearestPlayer(this, 128.0);
		if (near != null) {
			float closeness = 1.0F - (float) Mth.clamp(near.distanceTo(this) / 128.0, 0.0, 1.0);
			float volume = (2.0F + 0.8F * s) * (float) k;
			if (this.tickCount % 8 == 0) {
				this.level().playLocalSound(getX(), getY() + h * 0.3, getZ(),
						SoundEvents.ELYTRA_FLYING, SoundSource.WEATHER,
						volume, 0.5F + 0.5F * closeness, false);
			}
			if (this.tickCount % 80 == 0) {
				this.level().playLocalSound(getX(), getY() + h * 0.3, getZ(),
						SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER,
						volume + 1.0F, 0.45F + 0.15F * closeness, false);
			}
		}
	}
}
