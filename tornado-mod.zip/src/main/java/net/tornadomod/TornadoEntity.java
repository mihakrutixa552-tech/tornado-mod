package net.tornadomod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Tornado. Strength 1..5 corresponds to EF1..EF5 on the Enhanced Fujita scale.
 * Index of every table below = strength (index 0 is unused).
 */
public class TornadoEntity extends Entity {
	// ---- EF1 ... EF5 ----------------------------------------------------------
	/** Wind speed in mph (middle of the real EF range; EF5 is "over 200 mph"). */
	private static final int[] MPH = {0, 98, 123, 150, 183, 230};
	/** Funnel radius at the ground / at the cloud base, funnel height (blocks). */
	private static final double[] BASE_R = {0, 2.0, 3.0, 4.5, 6.5, 9.0};
	private static final double[] TOP_R = {0, 7.0, 10.0, 14.0, 19.0, 26.0};
	private static final double[] HEIGHT = {0, 28.0, 34.0, 42.0, 52.0, 64.0};
	/** Radius around the tornado in which blocks are torn out. */
	private static final double[] DAMAGE_R = {0, 3.0, 5.0, 8.0, 11.0, 16.0};
	/** Block-tearing attempts per 2 ticks, and how deep (below the top) trees/walls can be torn. */
	private static final int[] RIP_ATTEMPTS = {0, 4, 8, 14, 22, 34};
	private static final int[] RIP_DEPTH = {0, 1, 4, 8, 14, 24};
	/** Hardest block that can be torn out (obsidian is 50, bedrock is unbreakable: never torn). */
	private static final float[] MAX_HARDNESS = {0, 0.3F, 2.0F, 2.0F, 2.5F, 3.5F};
	/** Max number of flying debris blocks around one tornado (performance limit). */
	private static final int[] DEBRIS_CAP = {0, 20, 35, 55, 80, 110};

	private static final EntityDataAccessor<Integer> DATA_STRENGTH =
			SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Integer> DATA_MAX_LIFE =
			SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.INT);

	/** Direction of travel (radians), server side only. */
	private double heading;
	/** Flying debris blocks seen in the funnel during the previous tick (server only). */
	private int debrisCount;

	public TornadoEntity(EntityType<?> type, Level level) {
		super(type, level);
		this.noPhysics = true;
		this.setNoGravity(true);
		this.setInvulnerable(true);
		this.heading = this.random.nextDouble() * Math.PI * 2.0;
		int span = TornadoMod.LIFETIME_MAX_TICKS - TornadoMod.LIFETIME_MIN_TICKS;
		this.entityData.set(DATA_MAX_LIFE, TornadoMod.LIFETIME_MIN_TICKS + this.random.nextInt(span + 1));
	}

	// ------------------------------------------------------------------ data

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		builder.define(DATA_STRENGTH, 3);
		builder.define(DATA_MAX_LIFE, TornadoMod.LIFETIME_MIN_TICKS);
	}

	public int getStrength() {
		return this.entityData.get(DATA_STRENGTH);
	}

	public void setStrength(int strength) {
		this.entityData.set(DATA_STRENGTH, Mth.clamp(strength, 1, 5));
	}

	@Override
	protected void readAdditionalSaveData(ValueInput input) {
		setStrength(input.getIntOr("Strength", 3));
		this.entityData.set(DATA_MAX_LIFE, input.getIntOr("MaxLife", TornadoMod.LIFETIME_MIN_TICKS));
		this.tickCount = input.getIntOr("Age", 0);
	}

	@Override
	protected void addAdditionalSaveData(ValueOutput output) {
		output.putInt("Strength", getStrength());
		output.putInt("MaxLife", this.entityData.get(DATA_MAX_LIFE));
		output.putInt("Age", this.tickCount);
	}

	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		return false; // tornadoes can't be damaged
	}

	// -------------------------------------------------------------- geometry

	private double baseRadius() {
		return BASE_R[getStrength()];
	}

	private double topRadius() {
		return TOP_R[getStrength()];
	}

	private double height() {
		return HEIGHT[getStrength()];
	}

	/** 0..1: grows in during the first 3 s, fades out during the last 5 s of life. */
	private double intensity() {
		int maxLife = this.entityData.get(DATA_MAX_LIFE);
		double in = Mth.clamp(this.tickCount / 60.0, 0.0, 1.0);
		double out = Mth.clamp((maxLife - this.tickCount) / 100.0, 0.0, 1.0);
		return Math.max(0.1, Math.min(in, out));
	}

	/** Funnel radius at a height above the base: narrow at the bottom, flaring upwards. */
	private double funnelRadius(double relY, double k) {
		double t = Mth.clamp(relY / (height() * k), 0.0, 1.0);
		t = Math.pow(t, 1.6);
		return (baseRadius() + (topRadius() - baseRadius()) * t) * k;
	}

	private AABB influenceBox(double k) {
		double r = topRadius() * k;
		return new AABB(getX() - r, getY() - 2.0, getZ() - r, getX() + r, getY() + height() * k, getZ() + r);
	}

	// ------------------------------------------------------------------ tick

	@Override
	public void tick() {
		super.tick();

		if (this.level() instanceof ServerLevel server) {
			if (this.tickCount >= this.entityData.get(DATA_MAX_LIFE)) {
				this.discard();
				return;
			}
			moveAlongSurface(server);
			if (this.tickCount % 2 == 0) {
				ripBlocks(server);
			}
			affectEntities(server);
		} else {
			clientEffects();
		}
	}

	// ---------------------------------------------------------------- server

	private void moveAlongSurface(ServerLevel level) {
		double speed = 0.09 + 0.015 * getStrength();
		this.heading += (this.random.nextDouble() - 0.5) * 0.08;

		double nx = getX() + Math.cos(this.heading) * speed;
		double nz = getZ() + Math.sin(this.heading) * speed;
		int bx = Mth.floor(nx);
		int bz = Mth.floor(nz);

		if (!level.hasChunkAt(new BlockPos(bx, 0, bz))) {
			this.heading += Math.PI * 0.5; // don't wander into unloaded chunks
			return;
		}

		// Heightmap includes water surface, ignores leaves -> follows ground and water.
		int surface = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
		double ny = getY() + Mth.clamp((surface - getY()) * 0.25, -0.5, 0.5);
		this.setPos(nx, ny, nz);
	}

	private static boolean isAffected(Entity e) {
		if (e instanceof TornadoEntity || e instanceof HangingEntity) return false;
		if (e.isSpectator() || e.isRemoved() || e.isPassenger()) return false;
		if (e instanceof Player p && p.isCreative()) return false;
		if (e instanceof LivingEntity le && le.getMaxHealth() > 100.0F) return false; // bosses
		return true;
	}

	private void affectEntities(ServerLevel level) {
		int s = getStrength();
		double k = intensity();
		double h = height() * k;

		double mph = MPH[s];
		double flingSpeed = mph / 115.0;        // EF1 ~0.85 .. EF5 ~2.0 blocks/tick
		double spinAccel = 0.01 + mph / 3000.0;
		double maxHoriz = mph / 150.0;
		int debris = 0;

		for (Entity e : level.getEntities(this, influenceBox(k), TornadoEntity::isAffected)) {
			boolean falling = e instanceof FallingBlockEntity;
			if (falling) debris++;

			// heavy things need a stronger tornado: EF1 lifts light things, EF4+ lifts golems, EF5 anything
			double mass = e.getBbWidth() * e.getBbHeight();
			int needed = mass > 6.0 ? 5 : mass > 2.5 ? 4 : mass > 1.3 ? 2 : 1;
			if (s < needed) continue;

			double dx = e.getX() - getX();
			double dz = e.getZ() - getZ();
			double dist = Math.sqrt(dx * dx + dz * dz);
			double relY = e.getY() - getY();
			if (relY < -2.0 || relY > h) continue;

			double radius = funnelRadius(Math.max(relY, 0.0), k);
			if (dist > radius + e.getBbWidth()) continue;

			boolean light = falling || e instanceof ItemEntity || mass < 0.5;
			double nd = Math.max(dist, 0.4);
			double ux = dx / nd, uz = dz / nd; // outward
			double tx = -uz, tz = ux;          // tangent (counter-clockwise)

			if (!falling) e.resetFallDistance();
			Vec3 old = e.getDeltaMovement();
			Vec3 v;

			float flingChance = light ? 0.03F : 0.012F;
			boolean fling = relY > h * 0.8 || (relY > h * 0.35 && this.random.nextFloat() < flingChance);
			if (fling) {
				// thrown out of the funnel like a projectile
				double out = flingSpeed * (0.8 + this.random.nextDouble() * 0.5);
				v = new Vec3(ux * out + tx * 0.4, 0.3 + 0.05 * s, uz * out + tz * 0.4);
				if (e instanceof LivingEntity living && !living.hasEffect(MobEffects.SLOW_FALLING)) {
					living.hurtServer(level, level.damageSources().flyIntoWall(), 1.0F + 2.0F * s);
					// EF1-EF3: soft landing. EF4: short. EF5: none -> a fall from the funnel is usually lethal.
					if (s <= 4) {
						living.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, s <= 3 ? 200 : 60, 0, false, false));
					}
				}
			} else {
				// spiral: spin around + pull inwards + lift
				double spin = spinAccel * (light ? 1.3 : 1.0);
				double pull = (0.04 + 0.008 * s) * (0.4 + dist / Math.max(radius, 0.5));
				double lift = light ? 0.04 + 0.012 * s : 0.08 * (0.95 + 0.1 * s);
				double gravityEmulation = e instanceof ServerPlayer ? 0.08 : 0.0; // the server doesn't simulate players
				v = new Vec3(
						old.x * 0.85 + tx * spin - ux * pull,
						old.y * 0.92 + lift - gravityEmulation,
						old.z * 0.85 + tz * spin - uz * pull);

				double hs = Math.hypot(v.x, v.z);
				if (hs > maxHoriz) {
					v = new Vec3(v.x * maxHoriz / hs, v.y, v.z * maxHoriz / hs);
				}
				v = new Vec3(v.x, Mth.clamp(v.y, -0.6, 0.3 + 0.04 * s), v.z);
			}

			e.setDeltaMovement(v);
			if (e instanceof ServerPlayer) {
				e.hurtMarked = true; // make the server send the new motion to the client
			}
		}
		this.debrisCount = debris;
	}

	private void ripBlocks(ServerLevel level) {
		int s = getStrength();
		double k = intensity();

		int room = DEBRIS_CAP[s] - this.debrisCount;
		if (room <= 0) return;

		double reach = DAMAGE_R[s] * k;
		int attempts = Math.min((int) Math.ceil(RIP_ATTEMPTS[s] * k), room);

		for (int i = 0; i < attempts; i++) {
			double angle = this.random.nextDouble() * Math.PI * 2.0;
			double r = Math.sqrt(this.random.nextDouble()) * reach;
			int x = Mth.floor(getX() + Math.cos(angle) * r);
			int z = Mth.floor(getZ() + Math.sin(angle) * r);
			if (!level.hasChunkAt(new BlockPos(x, 0, z))) continue;

			// Top of the column (roofs and leaves count). Half of the attempts go deeper:
			// that is how trunks, walls and whole houses get taken apart from the top down.
			int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
			int depth = this.random.nextFloat() < 0.5F ? 0 : this.random.nextInt(RIP_DEPTH[s] + 1);
			BlockPos pos = new BlockPos(x, top - 1 - depth, z);
			BlockState state = level.getBlockState(pos);

			if (!canRip(level, pos, state, s)) continue;

			// Terrain (dirt, sand, gravel) is only scoured slowly and only from the surface layer.
			if (isGround(state) && (depth > 0 || this.random.nextFloat() > 0.3F)) continue;

			if (!isExposed(level, pos)) continue;

			FallingBlockEntity falling = FallingBlockEntity.fall(level, pos, state);
			falling.setDeltaMovement(0.0, 0.3 + 0.05 * s, 0.0);
			if (s >= 3) {
				// flung debris hurts whoever it lands on
				falling.setHurtsEntities(1.0F + s, 20 + 10 * s);
			}
			this.debrisCount++;
		}
	}

	/**
	 * What each strength can tear out:
	 * EF1 leaves, plants, glass, snow. EF2 + dirt, sand, wood (trees, roofs, planks).
	 * EF3 + bricks, concrete, cobblestone (outer walls of houses). EF4/EF5 even harder blocks.
	 * Never: block entities (chests, furnaces...), obsidian, bedrock, natural stone/deepslate, fluids.
	 */
	private static boolean canRip(ServerLevel level, BlockPos pos, BlockState state, int s) {
		if (state.isAir() || !state.getFluidState().isEmpty()) return false;
		if (state.hasBlockEntity()) return false;
		if (state.is(Blocks.OBSIDIAN) || state.is(Blocks.CRYING_OBSIDIAN) || state.is(Blocks.BEDROCK)) return false;
		if (state.is(BlockTags.WITHER_IMMUNE) || state.is(BlockTags.BASE_STONE_OVERWORLD)) return false;
		float hardness = state.getDestroySpeed(level, pos);
		if (hardness < 0.0F || hardness > MAX_HARDNESS[s]) return false;
		if (state.requiresCorrectToolForDrops()) return s >= 3;
		return true;
	}

	private static boolean isGround(BlockState state) {
		return state.is(BlockTags.DIRT) || state.is(BlockTags.SAND) || state.is(Blocks.GRAVEL);
	}

	private static boolean isExposed(ServerLevel level, BlockPos pos) {
		for (Direction d : Direction.values()) {
			BlockState n = level.getBlockState(pos.relative(d));
			if (n.isAir() || n.canBeReplaced()) return true;
		}
		return false;
	}

	// ---------------------------------------------------------------- client

	private void clientEffects() {
		int s = getStrength();
		double k = intensity();
		double h = height() * k;

		// Level of detail: the farther the nearest player, the fewer particles
		Player near = this.level().getNearestPlayer(this, 256.0);
		double distance = near == null ? 256.0 : near.distanceTo(this);
		int lod = distance < 64.0 ? 1 : distance < 128.0 ? 2 : 4;

		if (this.tickCount % lod == 0) {
			spawnParticles(s, k, h, lod);
		}

		if (near != null) {
			float closeness = 1.0F - (float) Mth.clamp(distance / 128.0, 0.0, 1.0);
			float volume = (2.0F + 0.8F * s) * (float) k;
			float pitch = Mth.clamp(0.6F - 0.03F * s + 0.4F * closeness, 0.5F, 2.0F);
			if (this.tickCount % 8 == 0) {
				this.level().playLocalSound(getX(), getY() + h * 0.3, getZ(),
						SoundEvents.ELYTRA_FLYING, SoundSource.WEATHER,
						volume, pitch, false);
			}
			if (this.tickCount % 80 == 0) {
				this.level().playLocalSound(getX(), getY() + h * 0.3, getZ(),
						SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER,
						volume + 1.0F, Mth.clamp(0.45F + 0.15F * closeness, 0.5F, 2.0F), false);
			}
		}
	}

	private void spawnParticles(int s, double k, double h, int lod) {
		double density = TornadoMod.PARTICLE_DENSITY * (lod == 1 ? 1.0 : 0.5 * lod);

		BlockState ground = this.level().getBlockState(BlockPos.containing(getX(), getY() - 1.0, getZ()));
		if (ground.isAir() || !ground.getFluidState().isEmpty()) {
			ground = Blocks.DIRT.defaultBlockState();
		}
		ParticleOptions debris = new BlockParticleOption(ParticleTypes.BLOCK, ground);

		// 1) the funnel: particles sit on its surface, so the outline is clearly visible
		int funnel = (int) ((14 + 7 * s) * k * density);
		double spin = 0.25 + 0.05 * s;
		for (int i = 0; i < funnel; i++) {
			double t = Math.pow(this.random.nextDouble(), 1.3); // denser near the ground
			double relY = t * h;
			double r = funnelRadius(relY, k) * (0.85 + this.random.nextDouble() * 0.2);
			double angle = this.tickCount * 0.45 + t * 8.0 + this.random.nextDouble() * 0.5; // twisted funnel
			double px = getX() + Math.cos(angle) * r;
			double py = getY() + relY;
			double pz = getZ() + Math.sin(angle) * r;
			double vx = -Math.sin(angle) * spin;
			double vz = Math.cos(angle) * spin;
			double vy = 0.05 + this.random.nextDouble() * 0.2;

			double roll = this.random.nextDouble();
			ParticleOptions type;
			if (roll < 0.50) {
				type = ParticleTypes.LARGE_SMOKE;
			} else if (roll < 0.70) {
				type = ParticleTypes.CLOUD;
			} else {
				type = t < 0.6 ? debris : ParticleTypes.LARGE_SMOKE; // debris only in the lower part
			}
			this.level().addAlwaysVisibleParticle(type, px, py, pz, vx, vy, vz);
		}

		// 2) dust and debris ring on the ground (the "debris cloud")
		int dust = (int) ((4 + 2 * s) * k * density);
		double dustRadius = DAMAGE_R[s] * k;
		for (int i = 0; i < dust; i++) {
			double angle = this.random.nextDouble() * Math.PI * 2.0;
			double rad = Math.sqrt(this.random.nextDouble()) * dustRadius;
			double px = getX() + Math.cos(angle) * rad;
			double pz = getZ() + Math.sin(angle) * rad;
			double py = getY() + 0.3 + this.random.nextDouble() * 1.5;
			ParticleOptions type = this.random.nextBoolean() ? ParticleTypes.POOF : debris;
			this.level().addAlwaysVisibleParticle(type, px, py, pz,
					-Math.sin(angle) * 0.15, 0.1 + this.random.nextDouble() * 0.15, Math.cos(angle) * 0.15);
		}

		// 3) dark, rotating cloud base on top of the funnel
		int cloud = (int) ((3 + s) * k * density);
		for (int i = 0; i < cloud; i++) {
			double angle = this.random.nextDouble() * Math.PI * 2.0;
			double rad = topRadius() * k * (0.7 + this.random.nextDouble() * 0.9);
			this.level().addAlwaysVisibleParticle(ParticleTypes.LARGE_SMOKE,
					getX() + Math.cos(angle) * rad, getY() + h + this.random.nextDouble() * 3.0, getZ() + Math.sin(angle) * rad,
					-Math.sin(angle) * 0.2, 0.0, Math.cos(angle) * 0.2);
		}
	}
}
