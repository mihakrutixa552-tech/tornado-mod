package net.tornadomod;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
	public static final ResourceKey<EntityType<?>> TORNADO_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, TornadoMod.id("tornado"));

	public static final EntityType<TornadoEntity> TORNADO = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			TORNADO_KEY,
			EntityType.Builder.<TornadoEntity>of(TornadoEntity::new, MobCategory.MISC)
					.sized(2.0F, 4.0F)
					.fireImmune()
					.clientTrackingRange(16)
					.updateInterval(2)
					.build(TORNADO_KEY));

	private ModEntities() {
	}

	/** Calling this loads the class, which registers the entity type. */
	public static void register() {
	}
}
