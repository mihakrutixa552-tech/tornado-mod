package net.tornadomod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

public final class TornadoCommand {
	/** How far (blocks) the crosshair is traced. Kept within normally loaded chunks. */
	private static final double MAX_AIM_DISTANCE = 80.0;

	private TornadoCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(Commands.literal("tornado")
						.requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
						.then(Commands.literal("spawn")
								.executes(ctx -> spawn(ctx.getSource(), 3))
								.then(Commands.argument("strength", IntegerArgumentType.integer(1, 5))
										.executes(ctx -> spawn(ctx.getSource(),
												IntegerArgumentType.getInteger(ctx, "strength")))))
						.then(Commands.literal("clear")
								.executes(ctx -> clear(ctx.getSource())))));
	}

	/** Spawns the tornado where the crosshair points (strength 1..5 = EF1..EF5). */
	private static int spawn(CommandSourceStack source, int strength) {
		ServerLevel level = source.getLevel();
		Vec3 pos = source.getPosition();

		Entity executor = source.getEntity();
		if (executor != null) {
			Vec3 eye = executor.getEyePosition();
			Vec3 end = eye.add(executor.getLookAngle().scale(MAX_AIM_DISTANCE));
			// Fluid.ANY: aiming at a lake puts the tornado on the water surface
			BlockHitResult hit = level.clip(new ClipContext(
					eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.ANY, executor));
			pos = hit.getLocation(); // if nothing is hit this is the far end of the ray
		}

		BlockPos column = BlockPos.containing(pos);
		if (!level.hasChunkAt(column)) {
			source.sendFailure(Component.literal("Слишком далеко: там не загружена местность"));
			return 0;
		}

		int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(pos.x), Mth.floor(pos.z));

		TornadoEntity tornado = new TornadoEntity(ModEntities.TORNADO, level);
		tornado.setPos(pos.x, y, pos.z);
		tornado.setStrength(strength);
		level.addFreshEntity(tornado);

		source.sendSuccess(() -> Component.literal("Торнадо EF" + strength + " создано в точке прицела"), true);
		return 1;
	}

	private static int clear(CommandSourceStack source) {
		int removed = 0;
		for (ServerLevel level : source.getServer().getAllLevels()) {
			List<TornadoEntity> found = new ArrayList<>();
			for (Entity e : level.getAllEntities()) {
				if (e instanceof TornadoEntity t) found.add(t);
			}
			for (TornadoEntity t : found) {
				t.discard();
				removed++;
			}
		}
		final int total = removed;
		source.sendSuccess(() -> Component.literal("Удалено торнадо: " + total), true);
		return total;
	}
}
