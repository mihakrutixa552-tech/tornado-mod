package net.tornadomod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

public final class TornadoCommand {
	private TornadoCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(Commands.literal("tornado")
						.requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
						.then(Commands.literal("spawn")
								.executes(ctx -> spawn(ctx.getSource(), 3))
								.then(Commands.argument("strength", IntegerArgumentType.integer(1, 5))
										.executes(ctx -> spawn(ctx.getSource(),
												IntegerArgumentType.getInteger(ctx, "strength")))))
						.then(Commands.literal("clear")
								.executes(ctx -> clear(ctx.getSource())))));
	}

	private static int spawn(CommandSourceStack source, int strength) {
		ServerLevel level = source.getLevel();
		Vec3 pos = source.getPosition();

		// spawn 24 blocks in front of whoever ran the command
		Entity executor = source.getEntity();
		if (executor != null) {
			Vec3 look = executor.getLookAngle();
			Vec3 flat = new Vec3(look.x, 0.0, look.z).normalize();
			pos = pos.add(flat.scale(24.0));
		}

		int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(pos.x), Mth.floor(pos.z));

		TornadoEntity tornado = new TornadoEntity(ModEntities.TORNADO, level);
		tornado.setPos(pos.x, y, pos.z);
		tornado.setStrength(strength);
		level.addFreshEntity(tornado);

		source.sendSuccess(() -> Component.literal("Торнадо создан (сила " + strength + ")"), true);
		return 1;
	}

	private static int clear(CommandSourceStack source) {
		int removed = 0;
		for (ServerLevel level : source.getServer().getAllLevels()) {
			List<TornadoEntity> found = new ArrayList<>();
			for (Entity e : level.getAllEntities()) {
				if (e instanceof TornadoEntity t) found.add(t);
			}
			for (TornadoEntity t : found) {
				t.discard();
				removed++;
			}
		}
		final int total = removed;
		source.sendSuccess(() -> Component.literal("Удалено торнадо: " + total), true);
		return total;
	}
}
