package net.tornadomod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

public class TornadoMod implements ModInitializer {
	public static final String MOD_ID = "tornadomod";

	/** Tornado lifetime in ticks (20 ticks = 1 second): random between MIN and MAX. */
	public static final int LIFETIME_MIN_TICKS = 20 * 120; // 2 minutes
	public static final int LIFETIME_MAX_TICKS = 20 * 180; // 3 minutes

	/** Multiplier for client particle count (lower it if the game lags). */
	public static final double PARTICLE_DENSITY = 1.0;

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModEntities.register();
		TornadoCommand.register();
		TornadoSpawner.register();
	}
}
