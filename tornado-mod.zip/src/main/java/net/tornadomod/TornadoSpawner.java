package net.tornadomod;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.List;

/** Rare natural tornadoes during thunderstorms in plains, desert and savanna. */
public final class TornadoSpawner {
	private static final int CHECK_INTERVAL_TICKS = 200; // every 10 s
	private static final double SPAWN_CHANCE = 0.02;     // per check -> roughly one per ~8 min of storm
	private static final int MAX_PER_WORLD = 2;
	private static final double MIN_DISTANCE_BETWEEN = 96.0;

	private TornadoSpawner() {
	}

	public static void register() {
		ServerTickEvents.END_LEVEL_TICK.register(TornadoSpawner::tick);
	}

	private static void tick(ServerLevel level) {
		if (level.getGameTime() % CHECK_INTERVAL_TICKS != 0) return;
		if (!level.dimension().equals(Level.OVERWORLD)) return;
		if (!level.isThundering()) return;

		RandomSource random = level.getRandom();
		if (random.nextDouble() > SPAWN_CHANCE) return;

		List<ServerPlayer> players = level.players();
		if (players.isEmpty()) return;

		int existing = 0;
		for (Entity e : level.getAllEntities()) {
			if (e instanceof TornadoEntity) existing++;
		}
		if (existing >= MAX_PER_WORLD) return;

		ServerPlayer player = players.get(random.nextInt(players.size()));
		double angle = random.nextDouble() * Math.PI * 2.0;
		double distance = 48.0 + random.nextDouble() * 48.0;
		int x = Mth.floor(player.getX() + Math.cos(angle) * distance);
		int z = Mth.floor(player.getZ() + Math.sin(angle) * distance);

		if (!level.hasChunkAt(new BlockPos(x, 0, z))) return;
		int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
		BlockPos pos = new BlockPos(x, y, z);

		if (!level.canSeeSky(pos)) return;                 // open terrain only
		if (!isTornadoBiome(level.getBiome(pos))) return;

		for (Entity e : level.getAllEntities()) {
			if (e instanceof TornadoEntity && e.distanceToSqr(x, y, z) < MIN_DISTANCE_BETWEEN * MIN_DISTANCE_BETWEEN) {
				return;
			}
		}

		TornadoEntity tornado = new TornadoEntity(ModEntities.TORNADO, level);
		tornado.setPos(x + 0.5, y, z + 0.5);
		int strength = 1 + random.nextInt(3);
		if (random.nextFloat() < 0.15F) strength++;
		tornado.setStrength(strength);
		level.addFreshEntity(tornado);
	}

	private static boolean isTornadoBiome(Holder<Biome> biome) {
		return biome.is(Biomes.PLAINS)
				|| biome.is(Biomes.SUNFLOWER_PLAINS)
				|| biome.is(Biomes.DESERT)
				|| biome.is(Biomes.SAVANNA)
				|| biome.is(Biomes.SAVANNA_PLATEAU)
				|| biome.is(Biomes.WINDSWEPT_SAVANNA);
	}
}
